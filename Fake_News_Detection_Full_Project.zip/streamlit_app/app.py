import streamlit as st
import tensorflow as tf
import numpy as np
from PIL import Image
import json
import os

IMG_SIZE = (224, 224)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODELS_DIR, "fake_real_model.h5")
LABEL_MAP_PATH = os.path.join(MODELS_DIR, "label_map.json")

@st.cache_resource
def load_resources():
    if not os.path.exists(MODEL_PATH) or not os.path.exists(LABEL_MAP_PATH):
        st.error("Model or label map not found. Please train the model first (run src/train.py).")
        return None, None

    try:
        model = tf.keras.models.load_model(MODEL_PATH)
        with open(LABEL_MAP_PATH, "r") as f:
            idx_to_class = json.load(f)
            idx_to_class = {int(k): v for k, v in idx_to_class.items()}
        return model, idx_to_class
    except Exception as e:
        st.error(f"Error loading model or label map: {e}")
        return None, None

def predict_image(image, model, idx_to_class):
    img = image.convert('RGB').resize(IMG_SIZE)
    img_array = np.array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    pred = model.predict(img_array)[0][0]

    # threshold = 0.5 by default
    if pred >= 0.5:
        predicted_class = idx_to_class.get(1, 'real')
        confidence = pred
    else:
        predicted_class = idx_to_class.get(0, 'fake')
        confidence = 1.0 - pred

    return predicted_class, confidence, float(pred)

def main():
    st.set_page_config(
        page_title="Fake News Image Detector",
        layout="centered",
    )

    st.title("📰 Fake News Image Detection")
    st.write("Upload a news-related image to classify it as **FAKE** or **REAL**.")

    model, idx_to_class = load_resources()
    if model is None:
        return

    uploaded_file = st.file_uploader("Choose an image", type=['jpg', 'jpeg', 'png'])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_column_width=True)

        if st.button("Analyze Image"):
            with st.spinner("Analyzing..."):
                predicted_class, confidence, prob = predict_image(image, model, idx_to_class)

            st.subheader("Result")
            if predicted_class.lower() == "fake":
                st.error(f"🚨 Prediction: FAKE ({confidence*100:.2f}% confidence)")
            else:
                st.success(f"✅ Prediction: REAL ({confidence*100:.2f}% confidence)")

            st.write(f"Raw model output (P(class=1)): **{prob:.4f}**")

if __name__ == "__main__":
    main()
