# Dataset Placeholder

Place your Fake vs Real image dataset in this folder.

Expected structure:

fake_and_real/
    fake/
        img1.jpg
        img2.jpg
        ...
    real/
        img1.jpg
        img2.jpg
        ...
